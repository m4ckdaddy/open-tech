import json

def consolidate_report(json_file):
    with open(json_file, "r") as file:
        nodegoat_data = json.load(file)
    
    consolidated_data = []

    modules = nodegoat_data["static-analysis"]["modules"]["module"]
    for module in modules:
        data = {
            "name": module["name"],
            "version": nodegoat_data.get("version"),
            "scan_score": module["score"],
            "status": "",
            "very_high": module["numflawssev5"],
            "high": module["numflawssev4"],
            "medium": module["numflawssev3"]
        }
        consolidated_data.append(data)

    flaw_status_data = nodegoat_data.get("flaw-status", {})
    for data in consolidated_data:
        if flaw_status_data.get("new", 0) > 0:
            data["status"] = "new"
        elif flaw_status_data.get("open", 0) > 0:
            data["status"] = "open"
        elif flaw_status_data.get("fixed", 0) > 0:
            data["status"] = "fixed"
        else:
            data["status"] = "unknown"

    return consolidated_data

if __name__ == "__main__":
    json_file_path = input("Enter the path to the JSON file: ")
    consolidated_data = consolidate_report(json_file_path)
    
    for data in consolidated_data:
        print("\nModule:", data["name"])
        print("Version:", data["version"])
        print("Scan Score:", data["scan_score"])
        print("Status:", data["status"])
        print("Very High Severity Flaws:", data["very_high"])
        print("High Severity Flaws:", data["high"])
        print("Medium Severity Flaws:", data["medium"])