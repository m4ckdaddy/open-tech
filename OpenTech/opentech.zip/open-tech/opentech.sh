#!/bin/bash
#Prompt the user for application profile

echo "Please enter application profile name:"
read app_name

#HTTP GET Requests
response=$(http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?name=${app_name}")
reply=$(echo $response | grep -i $app_name | cut -d ',' -f4)
echo $reply

# Extract the guid
guid=$(echo $reply | cut -d '"' -f4)

echo "The GUID for '${app_name}' is: ${guid}'"
set guid=guid
export guid
echo "############HERE IS GUID ##########"
echo $guid

guid=$guid

http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v2/applications/${guid}/summary_report" > "$app_name".json