#!/bin/bash
read -p "Enter type (gem/maven/npm/pypi/cocoapods/go/packagist/nuget): " type
read -p "Enter coord1 value: " coord1
read -p "Enter coord2 value (Press Enter if not applicable): " coord2
read -p "Enter version (in format v-.0.0-{datetime}-{hash}): " version

# Construct the command
if [[ -z "$coord2" ]]; then
    srcclr lookup --type="$type" --coord1="$coord1" --version="$version" --json
else
    srcclr lookup --type="$type" --coord1="$coord1" --coord2="$coord2" --version="$version" --json
fi
!/bin/bash
shopt -s expand_aliases
alias
alias 'veracode-http'='docker run -it --rm -v $PWD:/home/luser -v ~/.veracode/credentials:/home/luser/.veracode/credentials veracode/api-signing:cmd'
veracode-http "https://api.veracode.com/srcclr/v3/workspaces" > workspaces.json
jq -r '.content[] .name' ./workspaces.json

echo "enter a workspace GUID: "
read workspaceGUID
veracode-http "https://api.veracode.com/srcclr/v3/workspaces/$workspaceGUID/projects?type=agent"
echo "Enter a project GUID: "
read projectGUID
veracode-http "https://api.veracode.com/srcclr/sbom/v1/targets/$projectGUID/cyclonedx?type=agent"