#!/bin/bash

# Function to retrieve CVEs from NVD
get_cves() {
  # Parameters
  local library=$1
  local version=$2

  # Create the NVD API URL
  local url="https://services.nvd.nist.gov/rest/json/cves/1.0?cpeMatchString=cpe:2.3:a:${library}:${version}"

  # Send a GET request to the NVD API and parse the response with jq
  local response=$(curl -s "$url" | jq -r '.result.CVE_Items[] | .cve.CVE_data_meta.ID + ": " + .cve.description.description_data[0].value')

  # If there is no response, print an error message
  if [ -z "$response" ]; then
    echo "No CVEs found for ${library}:${version}"
  else
    # Print each CVE and its description
    echo "$response"
  fi
}

# Example usage: get the CVEs for a library and version
get_cves "library-name" "version"

