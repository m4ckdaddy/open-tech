# Prompt for the application profile name
echo "Please enter the application profile name: "
read app_name

# Use http with veracode_hmac to make the API request
response=$(http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?name=${app_name}")
reply=$(echo $response | grep -i $app_name | cut -d ',' -f4)
echo $reply
# If the 'guid' field is in the top level of the response, this will extract it
guid=$(echo $reply | cut -d '"' -f4)
echo $guid



# Print the guid
#echo "The application GUID for '${app_name}' is: ${guid}"
#python3 ./get_app_findings.py $guid
