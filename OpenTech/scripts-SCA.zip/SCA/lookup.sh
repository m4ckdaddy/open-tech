#!/bin/bash

# Path to your JSON file
json_file="./input.json"

# Iterate over each entry in the JSON file
for idx in $(jq -r 'keys[]' $json_file)
do
  # Get each field from the JSON object
  type=$(jq -r ".[$idx].type" $json_file)
  coord1=$(jq -r ".[$idx].coord1" $json_file)
  coord2=$(jq -r ".[$idx].coord2" $json_file)
  version=$(jq -r ".[$idx].version" $json_file)

  # Perform the lookup
  result=$(srcclr lookup --type $type --coord1 $coord1 --coord2 $coord2 --version $version --json)

  # If the result is not empty, print what it matched
  if [ -n "$result" ]; then
    echo "Matched: $type, $coord1, $coord2, $version"
  fi
done
