#!/bin/bash
/root/nvd.sh
