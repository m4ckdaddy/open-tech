curl --location 'https://api.veracode.com/appsec/v1/analytics/report/' \
--header 'Content-Type: application/json' \
--header 'Accept: application/json' \
--header 'Cookie: _cfuvid=ve2WZ62zpsajGSpKPAj5je6cq_9waZ9Y0shJNXZ6osE-1690396671059-0-604800000' \
--data '{
  "application_id": "1456095",
  "policy_sandbox": "Policy",
  "scan_type": [
    "Static Analysis"
  ],
  "policy_rule_passed": "true",
  "status": "Closed",
  "report_type": "findings",
  "last_updated_start_date": "2022-01-01",
  "latest_resolution_status": "Closed through Scan"
  ]
}'
