# SCA
Within this repo:
- [VDBlookupV3.sh](VDBlookupV3.sh) : Veracode Database Look Up Tool     
  - Todo: add the purl capability to the script
  - Todo: add the CPE lookup capability to the script
  - Todo: add the ability to parse an SBOM and provide all the vulnerability entries per component in more detail than the SBOM 
- [SBOM-WUI.sh](SBOM-WUI.sh) : SBOM Generator with interactive terminal UI ( can also be found [here](https://github.com/VCTD-Demo/SBOM/blob/main/SBOM-WUI.sh) )
- [vdb-purl-lte.sh](vdb-purl-lte.sh) : A light weight look up tool that takes in a PURL and then looks up in the database for the library matching the purl provided
