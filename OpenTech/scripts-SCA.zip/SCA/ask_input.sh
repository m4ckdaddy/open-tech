#!/bin/bash
#./get-app-guid.sh
echo "Please enter the application profile name: "
read app_name

# Use http with veracode_hmac to make the API request
response=$(http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/applications/?name=${app_name}")
reply=$(echo $response | grep -i $app_name | cut -d ',' -f4)
echo $reply
# If the 'guid' field is in the top level of the response, this will extract it
app_id=$(echo $reply | cut -d '"' -f4)
echo $app_id



# Print the guid



# Request user input for each field
echo "####### ENTER GUID OF THE APPLICATION PROFILE #######"
read -p "Enter app_id: " $app_id
echo "Enter scan_type. Choose one or more from: 'Static Analysis', 'Dynamic Analysis', 'Manual Analysis', 'SCA'"
read -a scan_type
echo "##### ENTER EITHER 'Policy' or 'Sandbox' ########" 
echo "Enter Type of Scan.: 'policy', 'sandbox'" 
read -a policy_sandbox
echo "##### ENTER yes/no for Policy_Rules_Passed ########"
read -a policy_rule_passed
echo "##### STATUS: 'open'/'closed'/'reopened' #########"
read -a status
echo "##### TYPE OF REPORT 'findings' #########"
read -a report_type
echo "##### DATE LAST UPDATED YYYY-MM-DD HH:MM:ss"
read -p "Enter last_updated_start_date: " last_updated_start_date
echo "##### DATE LAST END DATE: YYYY-MM-DD HH:MM:ss"
#read -p "Enter last_updated_end_date: " last_updated_end_date

# Print the JSON
echo "{
  \"app_id\": \"$app_id\",
  \"scan_type\": [\"${scan_type[@]}\"],
  \"policy_sandbox\": \"$policy_sandbox\",
  \"policy_rule_passed\": \"$policy_rule_passed\",
  \"status\": \"$status\",
  \"report_type\": \"$report_type\",
  \"last_updated_start_date\": \"$last_updated_start_date\",
  \"last_updated_end_date\": \"$last_updated_end_date\"
}"

reporting_id=$(http --auth-type=veracode_hmac POST "https://api.veracode.com/appsec/v1/analytics/report" < input.json) 
echo $reporting_id
id=$(echo $reporting_id | cut -d '"' -f6)
echo "pause for 30 seconds"
sleep 30
echo "resuming"
echo "#### THIS IS ID######"
echo $id
# Enter in the ID from the previous method
http --auth-type=veracode_hmac GET "https://api.veracode.com/appsec/v1/analytics/report/$id" | jq > report.json
#cat report.json
