#!/bin/bash

# Your JSON data
http --auth-type=veracode_hmac GET https://api.veracode.com/srcclr/api3/workspaces > json

#export output.son=json 

# Use grep and sed to parse the JSON data
last_scan_date=$(echo "$json" | grep -oP '"last_scan_date": "\K[^"]+')
id=$(echo "$json" | grep -oP '"id": "\K[^"]+')
name=$(echo "$json" | grep -oP '"name": "\K[^"]+')

# Print the results
echo "Last Scan Date: $last_scan_date"
echo "ID: $id"
echo "Name: $name"

